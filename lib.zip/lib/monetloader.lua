-- Copyright (c) MonetLoader, 2023
-- Built-in library: monetloader
-- Lua package is distributed under the MIT license

return {}